import socket

def start_server(ip_address, port):
    try:
        # 서버 소켓 생성
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind((ip_address, port))
        server_socket.listen(5)  # 최대 연결 대기 수

        print(f"서버가 {ip_address}:{port} 에서 시작되었습니다.")

        while True:
            # 클라이언트의 연결을 대기하고 수락
            client_socket, client_address = server_socket.accept()
            print(f"{client_address}가 연결되었습니다.")

            # 파일명 수신
            received_file_name = client_socket.recv(1024).decode()
            print(f"수신할 파일: {received_file_name}")

            # 파일 열고 데이터를 쓰기 시작
            with open(received_file_name, 'wb') as file:
                while True:
                    data = client_socket.recv(1024)
                    if not data:
                        break
                    file.write(data)

            print(f"{received_file_name} 파일을 성공적으로 수신하였습니다.")

            # 클라이언트 소켓 닫기
            client_socket.close()

    except Exception as e:
        print(f'에러 발생: {e}')

    finally:
        # 서버 소켓 닫기
        server_socket.close()

if __name__ == "__main__":
    ip_address = '172.30.1.56'  # 사용할 IP 주소
    port = 12345  # 사용할 포트 번호
    start_server(ip_address, port)
