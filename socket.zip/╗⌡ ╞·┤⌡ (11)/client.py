import socket
import base64  # 이미지를 전송하기 위해 추가

def start_client():
    server_address = ('192.168.0.16', 12345)

    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect(server_address)
        print('서버에 연결되었습니다.')

        while True:
            command = input('명령을 입력하세요 (GET_FILE:파일명, RUN_FILE:파일명, on, 사진 전송:SEND_PHOTO, 종료:quit): ')
            client_socket.send(command.encode())

            if command.lower() == 'quit':
                break

            if command.lower() == 'SEND_PHOTO':
                receive_photo(client_socket)

            data = client_socket.recv(1024)
            print(f'서버 응답: {data.decode()}')

    except Exception as e:
        print(f'에러 발생: {e}')

    finally:
        client_socket.close()

def receive_photo(client_socket):
    try:
        # Base64로 인코딩된 이미지 데이터 수신
        encoded_photo = client_socket.recv(4096)
        if encoded_photo == b'FILE_NOT_FOUND':
            print('파일이 존재하지 않습니다.')
        else:
            # Base64 디코딩 후 이미지 파일로 저장
            photo_data = base64.b64decode(encoded_photo)
            with open('received_photo.jpg', 'wb') as received_photo_file:
                received_photo_file.write(photo_data)
                print('이미지를 성공적으로 받았습니다.')

    except Exception as e:
        print(f'에러 발생: {e}')

if __name__ == "__main__":
    start_client()
