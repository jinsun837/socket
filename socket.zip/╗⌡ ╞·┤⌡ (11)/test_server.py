import socket
import os
import serial
import base64

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = ('0.0.0.0', 12345)

    # 아두이노 시리얼 통신을 위한 변수 초기화
    arduino_serial = None

    try:
        server_socket.bind(server_address)
        server_socket.listen(1)
        print('서버 대기 중...')

        client_socket, client_address = server_socket.accept()
        print('클라이언트가 연결되었습니다:', client_address)

        # 아두이노 시리얼 통신을 위한 연결 설정
        arduino_serial = serial.Serial('COM10', 9600)

        while True:
            data = client_socket.recv(1024)
            if not data:
                break
            message = data.decode()

            if message.startswith('GET_FILE:'):
                filename = message.split(':')[1]
                send_file(client_socket, filename)

            elif message.startswith('RUN_FILE:'):
                filename = message.split(':')[1]
                execute_file(filename)

            elif message.lower() == 'on':
                arduino_serial.write(b'on')
                print('Arduino를 켰습니다.')

            elif message.lower() == 'off':
                arduino_serial.write(b'off')
                print('Arduino를 종료합니다.')
                break  # Exit the loop and close the server

            elif message.lower() == 'SEND_PHOTO':
                send_photo(client_socket)

            else:
                print(f'수신한 메시지: {message}')
                response = input('응답을 입력하세요: ')
                client_socket.send(response.encode())

    except Exception as e:
        print(f'에러 발생: {e}')

    finally:
        # 아두이노 시리얼 통신 종료
        if arduino_serial:
            arduino_serial.close()
        server_socket.close()

# The rest of your code remains unchanged

if __name__ == "__main__":
    start_server()
