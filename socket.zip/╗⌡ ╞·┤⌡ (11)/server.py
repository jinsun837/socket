import socket

def start_server(ip_address, port):
    try:
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind((ip_address, port))
        server_socket.listen(5)  # 최대 연결 대기 수

        print(f"서버가 {ip_address}:{port} 에서 시작되었습니다.")

        while True:
            client_socket, client_address = server_socket.accept()
            print(f"{client_address}가 연결되었습니다.")

            # 클라이언트와의 통신 또는 작업 수행

            client_socket.close()

    except Exception as e:
        print(f'에러 발생: {e}')

    finally:
        server_socket.close()

if __name__ == "__main__":
    ip_address = '172.30.1.56'  # 사용할 IP 주소
    port = 12345  # 사용할 포트 번호
    start_server(ip_address, port)