import socket
import os
import serial
import base64
import threading

def send_file(client_socket, filename):
    try:
        with open(filename, 'rb') as file:
            file_data = file.read()
            client_socket.sendall(file_data)
    except FileNotFoundError:
        client_socket.send(b'FILE_NOT_FOUND')
    except Exception as e:
        print(f'에러 발생: {e}')

def execute_file(filename):
    try:
        os.system(filename)
    except Exception as e:
        print(f'에러 발생: {e}')

def send_photo(client_socket):
    try:
        photo_filename = 'example.jpg'
        with open(photo_filename, 'rb') as photo_file:
            photo_data = photo_file.read()
            encoded_photo = base64.b64encode(photo_data)
            client_socket.send(encoded_photo)

    except FileNotFoundError:
        client_socket.send(b'FILE_NOT_FOUND')
    except Exception as e:
        print(f'에러 발생: {e}')

def handle_user_input(client_socket):
    while True:
        response = input('응답을 입력하세요: ')
        client_socket.send(response.encode())

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = ('0.0.0.0', 12345)

    # 아두이노 시리얼 통신을 위한 변수 초기화
    arduino_serial = None

    try:
        server_socket.bind(server_address)
        server_socket.listen(1)
        print('서버 대기 중...')

        client_socket, client_address = server_socket.accept()
        print('클라이언트가 연결되었습니다:', client_address)

        # 아두이노 시리얼 통신을 위한 연결 설정
        arduino_serial = serial.Serial('COM10', 9600)

        # 쓰레드를 사용하여 사용자 입력 처리
        input_thread = threading.Thread(target=handle_user_input, args=(client_socket,))
        input_thread.start()

        while True:
            data = client_socket.recv(1024)
            if not data:
                break
            message = data.decode()

            if message.startswith('GET_FILE:'):
                filename = message.split(':')[1]
                send_file(client_socket, filename)

            elif message.startswith('RUN_FILE:'):
                filename = message.split(':')[1]
                execute_file(filename)

            elif message.lower() == 'on':
                arduino_serial.write(b'on')
                print('Arduino를 켰습니다.')

            elif message.lower() == 'off':
                arduino_serial.write(b'off')
                print('Arduino를 종료합니다.')
                break  # Exit the loop and close the server

            elif message.lower() == 'SEND_PHOTO':
                send_photo(client_socket)

            else:
                print(f'수신한 메시지: {message}')

    except Exception as e:
        print(f'에러 발생: {e}')

    finally:
        # 아두이노 시리얼 통신 종료
        if arduino_serial:
            arduino_serial.close()
        server_socket.close()

if __name__ == "__main__":
    start_server()
