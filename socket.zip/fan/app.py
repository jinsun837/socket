from flask import Flask, render_template
import socket

app = Flask(__name__)

# 소켓 서버 연결 여부 체크 함수
def check_socket_connection():
    try:
        socket.create_connection(("localhost", 포트번호), timeout=1)
        return True
    except Exception as e:
        print(e)
        return False

# 웹 페이지 라우팅 및 데이터 전달
@app.route('/')
def index():
    # 선풍기 상태 (On/Off)
    fan_status = "On"
    # 소켓 서버 연결 여부
    socket_status = check_socket_connection()
    # 가동시간 (예시로 5시간으로 가정)
    operating_hours = 5
    # 에너지 소비량 (예시로 10 킬로와트로 가정)
    energy_consumption = 10
    # 에너지 절약량 (예시로 2 킬로와트로 가정)
    energy_saving = 2
    
    return render_template('index.html', fan_status=fan_status, socket_status=socket_status, 
                           operating_hours=operating_hours, energy_consumption=energy_consumption, 
                           energy_saving=energy_saving)

if __name__ == '__main__':
    app.run(debug=True)
