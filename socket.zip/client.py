import socket
import os

def send_file(ip_address, port, file_path):
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((ip_address, port))

        file_name = os.path.basename(file_path)
        client_socket.send(file_name.encode())

        with open(file_path, 'rb') as file:
            for chunk in iter(lambda: file.read(1024), b''):
                client_socket.send(chunk)

        print(f"File {file_name} successfully sent.")

    except Exception as e:
        print(f'Error occurred: {e}')

    finally:
        client_socket.close()

def download_file(server_ip, server_port):
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((server_ip, server_port))

        file_to_download = input("Enter the file name to download: ")

        client_socket.send(file_to_download.encode())

        with open(file_to_download, 'wb') as file:
            while True:
                data = client_socket.recv(1024)
                if not data:
                    break
                file.write(data)

        print(f"File {file_to_download} downloaded successfully.")

    except Exception as e:
        print(f'Error occurred: {e}')

    finally:
        client_socket.close()

if __name__ == "__main__":
    server_ip = '172.30.1.56'
    server_port = 12345
    file_to_send = 'path/to/file.txt'
    send_file(server_ip, server_port, file_to_send)
