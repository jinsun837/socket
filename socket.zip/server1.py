import socket
import os

def handle_client(client_socket):
    try:
        while True:
            data = client_socket.recv(1024).decode('utf-8').strip()
            if not data:
                break  # 데이터가 없으면 연결 종료
            print("Received from client:", data)

            # 파일 전송 명령 처리
            if data == "SEND_FILE":
                file_name = "example.txt"  # 전송할 파일 이름
                if os.path.exists(file_name):
                    with open(file_name, "rb") as file:
                        chunk = file.read(1024)
                        while chunk:
                            client_socket.send(chunk)
                            chunk = file.read(1024)
                    print(f"{file_name} sent successfully.")
                else:
                    client_socket.send(b"File not found.")
            
            # IoT 장치 제어 명령 처리
            elif data == "ON":
                print("Device turned ON")
                # 여기서 실제 장치를 켜는 코드를 호출
                client_socket.send(b"Device turned ON")
            elif data == "OFF":
                print("Device turned OFF")
                # 여기서 실제 장치를 끄는 코드를 호출
                client_socket.send(b"Device turned OFF")

    except socket.error as e:
        print("Socket error:", e)
    finally:
        client_socket.close()
        print("Connection closed")

def start_server(ip_address, port):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((ip_address, port))
    server_socket.listen(5)
    print(f"Server started at {ip_address}:{port}")

    try:
        while True:
            client_socket, _ = server_socket.accept()
            print("Client connected")
            handle_client(client_socket)
    finally:
        server_socket.close()
        print("Server shutdown")

if __name__ == "__main__":
    start_server('172.30.1.50', 12345)
